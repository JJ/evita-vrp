drmnode.new -g alc -p 10121 -v 3 -r tutorial.jar\!ec.drm.app.tutorial5.Launch -a -master master.params -slave slave.params

Preliminar implementation of a master/slave model only for illustrative purposes on how is it built. For a real experiment use ec.drm.masterslave instead or jump to the ec.drm.app.tutorial6